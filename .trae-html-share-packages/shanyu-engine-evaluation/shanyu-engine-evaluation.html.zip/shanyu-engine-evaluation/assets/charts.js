(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var accent3 = style.getPropertyValue('--accent3').trim();
  var accent4 = style.getPropertyValue('--accent4').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();
  var bg3 = style.getPropertyValue('--bg3').trim();

  // ── Chart 1: Module Lines Bar Chart ──
  var chart1 = echarts.init(document.getElementById('chart-module-lines'), null, { renderer: 'svg' });
  chart1.setOption({
    animation: false,
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      backgroundColor: bg3,
      borderColor: rule,
      textStyle: { color: ink },
      appendToBody: true,
      formatter: function(params) {
        var p = params[0];
        return p.name + '<br/>代码行数: <b>' + p.value.toLocaleString() + '</b>';
      }
    },
    grid: { left: '3%', right: '5%', bottom: '3%', top: '3%', containLabel: true },
    xAxis: {
      type: 'value',
      axisLabel: { color: muted, fontSize: 11, formatter: function(v) { return (v / 1000) + 'K'; } },
      axisLine: { lineStyle: { color: rule } },
      splitLine: { lineStyle: { color: rule, opacity: 0.5 } }
    },
    yAxis: {
      type: 'category',
      data: ['Diagnostics','DCC','Materials','ShaderGraph','Modeling','UI','ECS','VisualScript','Input','Build','Particles','RHI','Vulkan','Editor','Network','Audio','Animation','AI','Assets','Physics','Rendering'].reverse(),
      axisLabel: { color: ink, fontSize: 11 },
      axisLine: { lineStyle: { color: rule } },
      splitLine: { show: false }
    },
    series: [{
      type: 'bar',
      data: [5563,5114,7585,7574,8396,8804,9056,9988,11071,11398,13845,18062,18344,22722,22732,24095,21683,37235,25317,59354,84332].reverse(),
      itemStyle: {
        color: function(params) {
          var v = params.value;
          if (v > 50000) return accent2;
          if (v > 20000) return accent;
          if (v > 10000) return accent3;
          return accent4;
        },
        borderRadius: [0, 4, 4, 0]
      },
      barWidth: '60%',
      label: {
        show: true,
        position: 'right',
        color: muted,
        fontSize: 10,
        formatter: function(p) { return (p.value / 1000).toFixed(1) + 'K'; }
      }
    }]
  });
  window.addEventListener('resize', function() { chart1.resize(); });

  // ── Chart 2: Radar Chart ──
  var chart2 = echarts.init(document.getElementById('chart-radar'), null, { renderer: 'svg' });
  chart2.setOption({
    animation: false,
    tooltip: {
      backgroundColor: bg3,
      borderColor: rule,
      textStyle: { color: ink },
      appendToBody: true
    },
    radar: {
      indicator: [
        { name: '功能完成度', max: 100 },
        { name: '架构设计', max: 100 },
        { name: '代码质量', max: 100 },
        { name: '创新性', max: 100 },
        { name: '实用性', max: 100 },
        { name: '文档与测试', max: 100 },
        { name: '可运行性', max: 100 }
      ],
      center: ['50%', '55%'],
      radius: '65%',
      axisName: {
        color: ink,
        fontSize: 12,
        fontWeight: 700
      },
      splitArea: {
        areaStyle: {
          color: [bg2, bg3],
          opacity: 0.3
        }
      },
      axisLine: { lineStyle: { color: rule } },
      splitLine: { lineStyle: { color: rule, opacity: 0.6 } }
    },
    series: [{
      type: 'radar',
      data: [{
        value: [82, 85, 75, 80, 65, 45, 50],
        name: '山雨引擎',
        areaStyle: { color: accent, opacity: 0.15 },
        lineStyle: { color: accent, width: 2 },
        itemStyle: { color: accent2 },
        label: {
          show: true,
          color: ink,
          fontSize: 11,
          fontWeight: 700,
          formatter: '{c}'
        }
      }]
    }]
  });
  window.addEventListener('resize', function() { chart2.resize(); });
})();
